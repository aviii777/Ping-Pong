# pingpong
- A simple and fun game created with Canvas API and Javascript.
- User can play with CPU
- User can set speed like slow, medium and hard
- Display Highest score using Local storage

- Home Page

![image](https://user-images.githubusercontent.com/85643213/152886139-16b5ae1f-6748-4d18-879f-28ea3e0f30f9.png)

- Game Playground

![image](https://user-images.githubusercontent.com/85643213/152886214-0aac96ce-d264-4bce-b462-cdcce862d818.png)

- Display Highest Score

![image](https://user-images.githubusercontent.com/85643213/152886698-3ee267f6-81e4-44d1-83f6-9620279c387d.png)


